package tipos;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;

import junit.framework.TestCase;
import xtc.parser.Result;

@RunWith(Parameterized.class)
public class TestRule extends TestCase{
	
	private Result result;
	
	//private String fileName = "/home/daniel/Documentos/TCC/Gramáticas/rule.txt";
	@Parameter
	public String fileName;
	
	@Parameterized.Parameters
	public static Object[] data(){
		return new Object[]{
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/types/rule01.txt",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/types/rule02.txt",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/types/rule03.txt",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/types/rule04.txt",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/types/rule01_failure.txt",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/types/rule02_failure.txt",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/types/rule03_failure.txt",
		};
		
	}
	@Test
	public void testpRULE_TYPE()throws IOException{
		
		Reader reader = new FileReader(fileName);
		
		types pType = new types(reader, fileName);
		
		result = pType.pRULE_TYPE(0);
		
		assertThat(result, not(instanceOf(xtc.parser.ParseError.class)));
		
	}
}
