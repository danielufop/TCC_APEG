package apeg_definition;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import junit.framework.TestCase;
import xtc.parser.Result;
@RunWith(Parameterized.class)
public class TestGrammar_Def extends TestCase{
	
	private Result result;
	@Parameter
	public String fileName = "";
	
	@Parameters
	public static Object[] data(){
		return new Object[]{
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/preamble_grammar/grammar01.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/preamble_grammar/grammar02.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/preamble_grammar/grammar03.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/preamble_grammar/grammar04.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/preamble_grammar/grammar05.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/preamble_grammar/grammar06.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/preamble_grammar/grammar07.apeg"
		};
	}
	@Test
	public void testpOPERATORS_TYPE() throws IOException{
		
		Reader reader = new FileReader(fileName);
		
		apeg_definition pPreambleGrammar = new apeg_definition(reader, fileName);
		
		result = pPreambleGrammar.pgrammarDef(0);
		
		assertThat(result, not(instanceOf(xtc.parser.ParseError.class)));
	}
}
