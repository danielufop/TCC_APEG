package atributos;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import junit.framework.TestCase;
import xtc.parser.Result;
@RunWith(Parameterized.class)
public class TestVar_Decls extends TestCase{
	
	private Result result;
	@Parameter
	public String fileName = "";
	
	@Parameters
	public static Object[] data(){
		return new Object[]{
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/attributes/varDecl01.txt",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/attributes/varDecl02.txt",
		};
	}
	@Test
	public void testpOPERATORS_TYPE() throws IOException{
		
		Reader reader = new FileReader(fileName);
		
		attributes pAttributes = new attributes(reader, fileName);
		
		result = pAttributes.pvarDecl(0);
		
		assertThat(result, not(instanceOf(xtc.parser.ParseError.class)));
	}
}
