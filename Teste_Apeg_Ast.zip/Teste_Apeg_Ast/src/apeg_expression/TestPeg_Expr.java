package apeg_expression;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import junit.framework.TestCase;
import xtc.parser.Result;
@RunWith(Parameterized.class)
public class TestPeg_Expr extends TestCase{
	
	private Result result;
	@Parameter
	public String fileName = "";
	
	@Parameters
	public static Object[] data(){
		return new Object[]{
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr01.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr02.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr03.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr04.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr01_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr02_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr03_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr04_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr05_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr06_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr07_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr08_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr09_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr10_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr11_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr12_failure.apeg",
			"/home/daniel/Documentos/TCC/APEG_RATS/APEG_TEST/apeg_expression/pexpr13_failure.apeg"
		};
	}
	@Test
	public void testpOPERATORS_TYPE() throws IOException{
		
		Reader reader = new FileReader(fileName);
		
		apeg_expression pExpression = new apeg_expression(reader, fileName);
		
		result = pExpression.ppeg_expr(0);
		
		assertThat(result, not(instanceOf(xtc.parser.ParseError.class)));
	}
}
